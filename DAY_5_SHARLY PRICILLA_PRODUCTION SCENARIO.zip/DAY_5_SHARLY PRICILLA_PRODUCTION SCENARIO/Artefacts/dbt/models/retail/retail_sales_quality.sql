{{ config(materialized='view') }}

select
    transaction_id,
    transaction_date,
    product,
    quantity,
    unit_price,
    sale_status,
    amount
from {{ ref('stg_retail_sales') }}
