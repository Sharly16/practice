{{ config(materialized='view') }}

select
    transaction_id,
    cast(transaction_date as date) as transaction_date,
    product,
    cast(quantity as integer) as quantity,
    cast(unit_price as decimal(10,2)) as unit_price,
    lower(sale_status) as sale_status,
    cast(amount as decimal(10,2)) as amount
from {{ ref('retail_sales') }}
